#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "inc/hw_gpio.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "driverlib/rom.h"

// Sizin kendi LCD k�t�phanenizi dahil ediyoruz
#include "lcd.h"

// Fonksiyon prototipleri
void initmikro(void);
void timerkesme(void);

// Hocan�n kulland��� global de�i�kenler
int sn, dk, sa;

int main(void)
{
    // B�t�n ayarlar� yapan fonksiyonu �a��r
    initmikro();

    // Ana d�ng�. B�t�n i� kesme (interrupt) i�inde yap�ld��� i�in
    // buras� bo� kalabilir.
    while(1)
    {
    }
}

// Ba�latma fonksiyonu (Sizin lcd.h dosyan�za g�re g�ncellendi)
void initmikro()
{
    sn = 0; dk = 0; sa = 0; // Saati s�f�rla

    // Hocan�n saat ayar� (40 MHz)
    SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);
    // 40 Mhz

    // Gerekli donan�mlar�n enerjisini/saatini a�
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0); // Timer0 i�in
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);  // Port F (LED i�in)
    // NOT: LCD portunu (Port B) a�maya GEREK YOK,
    // ��nk� "Lcd_init()" fonksiyonu bunu zaten yap�yor (lcd.h'deki LCDPORTENABLE)

    // Pin ayarlar�
    // PF1 (K�rm�z� LED) ��k�� olarak ayarlan�yor (debug i�in)
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1);

    // NOT: LCD pinlerini (Port B) ��k�� yapmaya GEREK YOK,
    // ��nk� "Lcd_init()" fonksiyonu bunu zaten yap�yor.

    // Timer0'� 1 saniyede bir kesme �retecek �ekilde ayarla
    TimerConfigure(TIMER0_BASE, TIMER_CFG_A_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet() - 1); // 40Mhz'de 1 saniye

    // Interrupt (Kesme) ayarlar�
    IntMasterEnable();
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntRegister(TIMER0_BASE, TIMER_A, timerkesme);

    // Sizin LCD ba�latma fonksiyonunuz �a�r�l�yor
    Lcd_init();

    // Ayarlar bitti, Timer'� �al��t�r
    TimerEnable(TIMER0_BASE, TIMER_A);
}

// Kesme fonksiyonu (Sizin lcd.h dosyan�za g�re g�ncellendi)
void timerkesme()
{
    // Kesme bayra��n� en ba�ta temizle
    TimerIntClear(TIMER0_BASE, TIMER_A);

    // ---- SAAT MANTI�I ----
    sn++;
    if (sn == 60)
    {
        sn = 0;  dk++;
        if (dk == 60)
        {
            dk = 0;   sa++;
            if (sa == 24)
            {
                sa = 0;
            }
        }
    }

    // ---- LCD YAZDIRMA KISMI ----
    // Say�lar� ASCII karaktere �evirme ('0' ekleyerek)
    char sa_onlar = (sa / 10) + '0';
    char sa_birler = (sa % 10) + '0';
    char dk_onlar = (dk / 10) + '0';
    char dk_birler = (dk % 10) + '0';
    char sn_onlar = (sn / 10) + '0';
    char sn_birler = (sn % 10) + '0';

    // �mleci her saniye en ba�a (sat�r 0, s�tun 0) al
    // Not: Sizin Lcd_Goto fonksiyonunuz 0-indeksli (0,0) m�
    // yoksa 1-indeksli (1,1) mi ba�l�yor bilmiyorum.
    // Genelde (0,0) veya (1,1) en ba��d�r. (0,0) deniyorum.
    Lcd_Goto(0, 0);

    // Saati yazd�r (Lcd_Data yerine Lcd_Putch kullanarak)
    Lcd_Putch(sa_onlar);
    Lcd_Putch(sa_birler);
    Lcd_Putch('.'); // �dev notlar�nda "." istenmi�ti

    // Dakikay� yazd�r
    Lcd_Putch(dk_onlar);
    Lcd_Putch(dk_birler);
    Lcd_Putch('.');

    // Saniyeyi yazd�r
    Lcd_Putch(sn_onlar);
    Lcd_Putch(sn_birler);

    // K�rm�z� LED'i yak/s�nd�r (debug i�in)
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, ~GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_1));
}
