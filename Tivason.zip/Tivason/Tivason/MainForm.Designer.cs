﻿/*
 * Created by SharpDevelop.
 * User: kubil
 * Date: 21.12.2025
 * Time: 19:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Tivason
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtGonderSaat = new System.Windows.Forms.TextBox();
			this.btnSaatGonder = new System.Windows.Forms.Button();
			this.txtGonderMetin = new System.Windows.Forms.TextBox();
			this.btnMetinGonder = new System.Windows.Forms.Button();
			this.textBoxSaat = new System.Windows.Forms.TextBox();
			this.textBoxADC = new System.Windows.Forms.TextBox();
			this.textBoxButon = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// txtGonderSaat
			// 
			this.txtGonderSaat.Location = new System.Drawing.Point(49, 13);
			this.txtGonderSaat.Name = "txtGonderSaat";
			this.txtGonderSaat.Size = new System.Drawing.Size(100, 22);
			this.txtGonderSaat.TabIndex = 0;
			// 
			// btnSaatGonder
			// 
			this.btnSaatGonder.Location = new System.Drawing.Point(179, 11);
			this.btnSaatGonder.Name = "btnSaatGonder";
			this.btnSaatGonder.Size = new System.Drawing.Size(75, 23);
			this.btnSaatGonder.TabIndex = 1;
			this.btnSaatGonder.Text = "Saati Senkronize Et";
			this.btnSaatGonder.UseVisualStyleBackColor = true;
			this.btnSaatGonder.Click += new System.EventHandler(this.BtnSaatGonderClick);
			// 
			// txtGonderMetin
			// 
			this.txtGonderMetin.Location = new System.Drawing.Point(49, 71);
			this.txtGonderMetin.Name = "txtGonderMetin";
			this.txtGonderMetin.Size = new System.Drawing.Size(100, 22);
			this.txtGonderMetin.TabIndex = 2;
			// 
			// btnMetinGonder
			// 
			this.btnMetinGonder.Location = new System.Drawing.Point(179, 69);
			this.btnMetinGonder.Name = "btnMetinGonder";
			this.btnMetinGonder.Size = new System.Drawing.Size(75, 23);
			this.btnMetinGonder.TabIndex = 3;
			this.btnMetinGonder.Text = "Metni Yaz";
			this.btnMetinGonder.UseVisualStyleBackColor = true;
			this.btnMetinGonder.Click += new System.EventHandler(this.BtnMetinGonderClick);
			// 
			// textBoxSaat
			// 
			this.textBoxSaat.Location = new System.Drawing.Point(49, 163);
			this.textBoxSaat.Name = "textBoxSaat";
			this.textBoxSaat.Size = new System.Drawing.Size(100, 22);
			this.textBoxSaat.TabIndex = 4;
			// 
			// textBoxADC
			// 
			this.textBoxADC.Location = new System.Drawing.Point(49, 225);
			this.textBoxADC.Name = "textBoxADC";
			this.textBoxADC.Size = new System.Drawing.Size(100, 22);
			this.textBoxADC.TabIndex = 5;
			// 
			// textBoxButon
			// 
			this.textBoxButon.Location = new System.Drawing.Point(49, 290);
			this.textBoxButon.Name = "textBoxButon";
			this.textBoxButon.Size = new System.Drawing.Size(100, 22);
			this.textBoxButon.TabIndex = 6;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(578, 472);
			this.Controls.Add(this.textBoxButon);
			this.Controls.Add(this.textBoxADC);
			this.Controls.Add(this.textBoxSaat);
			this.Controls.Add(this.btnMetinGonder);
			this.Controls.Add(this.txtGonderMetin);
			this.Controls.Add(this.btnSaatGonder);
			this.Controls.Add(this.txtGonderSaat);
			this.Name = "MainForm";
			this.Text = "Tivason";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.TextBox textBoxButon;
		private System.Windows.Forms.TextBox textBoxADC;
		private System.Windows.Forms.TextBox textBoxSaat;
		private System.Windows.Forms.Button btnMetinGonder;
		private System.Windows.Forms.TextBox txtGonderMetin;
		private System.Windows.Forms.Button btnSaatGonder;
		private System.Windows.Forms.TextBox txtGonderSaat;
	}
}
